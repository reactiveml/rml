#ifndef IMPRESSIO_TOPO_H
#define IMPRESSIO_TOPO_H

#include "structure.h"

void impr_topo(MYSQL *mysql, int taille, int nb_noeud);

#endif
