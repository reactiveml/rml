#ifndef GENERATEUR_H
#define GENERATEUR_H
                                                                                                                                                             
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
                                                                                                                                                             
int gener_alea(int taille);
#endif
