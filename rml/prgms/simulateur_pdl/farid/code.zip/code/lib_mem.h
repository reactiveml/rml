#ifndef LIB_MEM_H
#define LIB_MEM_H
                                                                                                                                                             
#include"structure.h"
                                                                                                                                                             
void lib_mem(noeud *topologie);
                                                                                                                                                             
#endif

